﻿namespace FirstAPI.Models.DTOs
{
    public class EmployeeSalaryDTO
    {
        public int Id { get; set; }
        public float Salary { get; set; }
    }
}
