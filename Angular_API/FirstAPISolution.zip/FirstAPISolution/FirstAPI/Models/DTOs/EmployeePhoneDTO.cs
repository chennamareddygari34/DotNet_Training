﻿namespace FirstAPI.Models.DTOs
{
    public class EmployeePhoneDTO
    {
        public int Id { get; set; }
        public string Phone { get; set; }
    }
}
